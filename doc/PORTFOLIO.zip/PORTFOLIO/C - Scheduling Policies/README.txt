In Project 4 we were tasked with implementing different schedule policies (FIFO, SJF, RR) for running jobs. Before
running any policy, we recursively created jobs by reading the data from an input file and linking them together through
a nextJob variable in the job structure. Also, to help keep track of the time passed while running jobs, we used a
clock variable that incremented as each task ran.

For the FIFO policy, we simply went through each job, "ran" it, and incremented the clock variable by the correct length.

For the SJF policy, we created an array for the jobs, and then used bubble sort on that array to arrange the jobs in
ascending order. After, we had to reset the nextJob variables in to the correct values from the sorter array.

For the Round Robin Policy, we first determine the timeSlice value from the command line argument and use it as the
limit as to how long each job can run. When each job runs, if the length is greater than or equal to the timeSlice it
decrements the job length by the timeSlice. If it is less than the timeSlice, the length is set to 0.
Once a job hits a length of zero, a job counter is incremented to determine when all the jobs were finished. If the
last job in the cycle is reached and all the jobs are not finished, the cycle resets until all jobs are completed.

To implement the policy analysis, we added variables startTime and endTime to the job structure. These were set when the
jobs start running and end running using the clock variable. For FIFO and SJF, the response time of any job will be the
turnaround time of the previous job and the wait time will be the sum of all the previous job lengths. For Round Robin
however, due to the fact that jobs can be split up, we added the variables waitTimeRR and lastClockRR in the job
structure. waitTimeRR is used to calculate the wait time for each job and lastClockRR is used to keep track of where the
clock was when a job splits. Through the use of these variables we are able to keep track of how much time each job
waits before completing which can then be used to find turnaround time.

Workload 1: If all the jobs take less time than the timeSlice, then it will act as a FIFO policy in which all the
wait times and response times are the same.

Workload 2: If the workload has a very long job at the start and short jobs following, then the turnaround times of jobs
in a FIFO policy will all be large as each job has to wait for the first one to finish. IF the same workload is executed
with a SJF policy, the jobs will be reordered so all the shorter jobs will go first and they do not have to wait for
the longer one. Thus making the average turnaround time lower.

Workload 3: If a workload only has jobs that are shorter than the timeSlice value and are arranged in ascending order,
FIFO, SJF, and RR will all execute the obs in the same order. This will give them all the same average response,
turnaround and wait times.

Workload 4: If a workload has mostly very short jobs with a very long job at the end, then the wait time will be small
as there are no lengthy jobs to be waited for. The turnaround time however, is much larger because the last job is an
outlier from the rest of the short jobs and boosts the average turnaround.

Workload 5: Given that the first job must be 3, the average response is 5, and the average turnaround is 13, you can set
up and solve equations to find the correct lengths for the last two jobs.

Let's say that the three jobs are A, B, and C respectively...

(2A + B) / 3 = 5
6 + B = 15
B = 9

(3A + 2B + C)/3 = 13
9 + 18 + C = 39
C = 12

A=3 / B=9 / C=12








