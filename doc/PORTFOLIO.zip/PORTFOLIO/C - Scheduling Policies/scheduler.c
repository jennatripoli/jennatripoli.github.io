#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<stdbool.h>

typedef struct job {
	int id;
	int length;
	int startTime;
	int endTime;
	
	//used in RR only 
	int waitTimeRR; 
	int lastClockRR; 

	struct job *next;
		
} job_t;


// recursively read through file lines and store job metadata 
job_t* readJob(int* num, char* line, size_t len, FILE *file, ssize_t read) {
	if ((read = getline(&line, &len, file)) == -1) return NULL;
	
	job_t* newJob = malloc(sizeof(job_t));
	newJob->id = *num;
	newJob->length = atoi(line);
	*num += 1;
	newJob->next = readJob(num, line, len, file, read);
	return newJob;
}



int main(int argc, char **argv) {
	FILE *file;
	char* line = NULL;
	size_t len = 0;
	ssize_t read = -1;
	int num = 0;
		
	file = fopen(argv[2], "r");
	if (file == NULL) {
		printf("Workload file not found.\n");
		return -1;
	}
		
	job_t* job0 = readJob(&num, line, len, file, read);
	fclose(file);
	job_t* curJob = job0;
	//printf("Num = %d\n", num);
	
	int clock = 0;
	int respTime =0;
	int turnTime = 0; 
	int waitTime = 0;
	int respTotal = 0;
	int turnTotal = 0;
	int waitTotal = 0;
	
	//counts jobs
	int numJobs = 0; 
	//counts jobs done (RR only)
	int jobsDone = 0;
    
	// first-in first-out
	if(strcmp(argv[1], "FIFO") == 0) {
		printf("Execution trace with FIFO:\n");
		
	 	while (curJob != NULL) {
	 		//for policy analysis
	 		curJob->startTime = clock;
	 		clock += curJob->length;
	 		curJob->endTime = clock;
	 		
	 		printf("Job %d ran for: %d\n", curJob->id, curJob->length);
	 		//move to next job
	 		curJob = curJob->next;
	 	}
	 	printf("End of execution with FIFO.\n");
	 	
	 	// Policy Analysis
	 	curJob = job0; 
	 	//reset clock for analysis
	 	clock = 0;
	 	printf("Begin Analysizing FIFO:\n");
	 	while(curJob != NULL){
	 	  	// find number of jobs for averages
	 	  	if(curJob->next == NULL) numJobs = curJob->id + 1;
	 	  
	 	  	//get response time 
	 	  	respTime = curJob->startTime;
	 	  	respTotal += respTime;
	 	  
	 	  	//get turnaround time
	 	  	turnTime = curJob->endTime;
	 	  	turnTotal += turnTime;
	 	  
	 	  	//get wait time
	 	  	waitTime = clock; 
	 	  	waitTotal += waitTime;
	 	  
	 	  	printf("Job %d -- Response time: %d  Turnaround: %d  Wait: %d\n", curJob->id, respTime, turnTime, waitTime);
	 	  	clock += curJob->length;
		  	curJob = curJob->next;
	 	}	
	 	printf("Average -- Response: %f  Turnaround: %f  Wait %f\n", (float) respTotal/numJobs, (float) turnTotal/numJobs, (float) waitTotal/numJobs);
	 	printf("End analyzing FIFO.\n");
	 	
    
	// shortest job first	
	} else if (strcmp(argv[1], "SJF") == 0) {
		printf("Execution trace with SJF:\n");
	
		// initialize jobs[] to correct size
		job_t* jobs[num + 1];
	
	
		// set curJob to first job received
		curJob = job0;
	
		// populate jobs[] with all jobs
		for (int i = 0; i < num; i++) {
			jobs[i] = curJob;
			curJob = curJob->next;
		}
	
		// sort jobs in order of runtime (not fixing job_t->next)
		for (int i = 0; i < num - 1; i++) {
			for (int j = 0; j < num - i - 1; j++) {
				if (jobs[j]->length > jobs[j + 1]->length) {
					job_t* temp = jobs[j];
					jobs[j] = jobs[j + 1];
					jobs[j + 1] = temp;
				}
			}
		}

		// reset the job_t->next for all jobs
		for (int i = 0; i < num - 1; i++) {
			jobs[i]->next = jobs[i + 1]; 
		}
	
		// set last job_t->next to NULL
		jobs[num - 1]->next = NULL;
	
		// set curJob to first job_t in jobs[]
		curJob = jobs[0];
	
		// print job order
		while (curJob != NULL) {
			//for policy analysis
	 		curJob->startTime = clock;
	 		clock += curJob->length;
	 		curJob->endTime = clock;
	 		printf("Job %d ran for: %d\n", curJob->id, curJob->length);
	 		curJob = curJob->next;
		}
	
		// Policy Analysis
	 	curJob = jobs[0]; 
	 	//reset clock for analysis
	 	clock = 0;
	 	numJobs = 0;
	 	
	 	printf("Begin Analysizing SJF:\n");
	 	while(curJob != NULL){

	 	  	//get response time 
	 	  	respTime = curJob->startTime;
	 	  	respTotal += respTime;
	 	  
	 	  	//get turnaround time
	 	  	turnTime = curJob->endTime;
	 	  	turnTotal += turnTime;
	 	  
	 	  	//get wait time
	 	  	waitTime = clock; 
	 	  	waitTotal += waitTime;
	 	  
	 	  	printf("Job %d -- Response time: %d  Turnaround: %d  Wait: %d\n", curJob->id, respTime, turnTime, waitTime);
	 	  	clock += curJob->length;
	 	  	numJobs++;
		  	curJob = curJob->next;
	 	}	
	 	printf("Average -- Response: %f  Turnaround: %f  Wait %f\n", (float) respTotal/numJobs, (float) turnTotal/numJobs, (float) waitTotal/numJobs);
	 	printf("End analyzing SJF.\n");
	
    
	// round robin
	} else if (strcmp(argv[1], "RR") == 0) {
		printf("Execution trace with RR:\n");
	
	
		//get timeslice arg
		int timeSlice = atoi(argv[3]);

	
		curJob = job0;
		//find num of jobs / set start times to -1
		while (curJob!= NULL){
			numJobs++;
			curJob->startTime = -1;
			curJob = curJob->next;
		}
	
		clock = 0;
		curJob = job0;	
		while (curJob != NULL){
	
			// Run jobs when length is greater than timeSlice
			if(curJob->length >= timeSlice){
				
				//increment wait time
				curJob->waitTimeRR += (clock - curJob->lastClockRR);
		
		  		curJob->length -= timeSlice;
		  
		  		//for policy anaylisis (set start time / initalize waitTimeRR)
		  		if(curJob->startTime == -1){	
		    	  		curJob->startTime = clock;
		    	  	curJob -> waitTimeRR = clock;
		   		}
		   	
		  		clock += timeSlice;
		  		printf("Job %d ran for: %d\n", curJob->id, timeSlice);
		  	
		  		//check if job is done
		 		if(curJob->length == 0){
		  	  		jobsDone++;
		  	  		//for policy analysis (set end time)
		  	  		curJob->endTime = clock;
		  		}
		
		} else{
			// when job length is less than timeSlice & non zero
			if(curJob->length > 0 && curJob->length < timeSlice){
			
					
				//increment wait time
				curJob->waitTimeRR += (clock - curJob->lastClockRR);
			
		  		//for policy anaylisis (set start time / initalize waitTimeRR)
		  	  	if(curJob->startTime == -1){
		    	    		curJob->startTime = clock;
		    	    		curJob -> waitTimeRR = clock;
		   	  	}
		   	  
	 		  	printf("Job %d ran for: %d\n", curJob->id, curJob->length);
	 		
	 		  	//for policy analysis
	 		  	clock += curJob->length;
	 		
	 		  	curJob->length = 0;
	 		  	curJob->endTime = clock;
	 		  	jobsDone++;
	 		}
	 	}
	 	
	 	//check if all jobs are done
	 	if(jobsDone >= numJobs && jobsDone>0){
	 		printf("End of execution with RR.\n");
		  	break;
   		}
	 	 		
	 	//move to begining when at last job
	 	else if(curJob->next == NULL){
	 		curJob->lastClockRR = clock;
	 		curJob = job0;
	 	}
	 	
	 	//move to next job
	 	else{
	 	  	//saves the clock after job last ran (used to calculate wait time) 
	 	  	curJob->lastClockRR = clock;
	 	  	curJob = curJob->next;
	 	}
	 		
		}
	
		//RR Policy Analysis 
	 	printf("Begin Analysizing RR:\n");
	 	curJob = job0;
	 	while(curJob != NULL){
	 	  	//get response time 
	 	  	respTime = curJob->startTime;
	 	  	respTotal += respTime;
	 	  	
	 	  	  	//get turnaround time
	 	  	turnTime = curJob->endTime;
	 	  	turnTotal += turnTime;
	 	  	
	 	  	//get wait time
	 	  	waitTime = curJob->waitTimeRR; 
	 	  	waitTotal += curJob->waitTimeRR;
	 	  
	 	
	 	  

	 	  
	 	  	printf("Job %d -- Response time: %d  Turnaround: %d  Wait: %d\n", curJob->id, respTime, turnTime, waitTime);
	 	  	clock += curJob->length;
		  	curJob = curJob->next;
	 	}	
	 	printf("Average -- Response: %f  Turnaround: %f  Wait %f\n", (float) respTotal/numJobs, (float) turnTotal/numJobs, (float) waitTotal/numJobs);
	 	printf("End analyzing RR.\n");
	 	 	
	 	
			 	
	// unknown policy type
	} else {
		printf("Invalid scheduling policy.\n");
		return -1;
	  } 
	 
}







