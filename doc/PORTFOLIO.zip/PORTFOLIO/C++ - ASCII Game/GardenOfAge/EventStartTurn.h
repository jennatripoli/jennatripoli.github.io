#ifndef __START_TURN_EVENT_H__
#define __START_TURN_EVENT_H__

#include "Event.h"

#define START_TURN_EVENT "startturn"

class EventStartTurn : public df::Event {
 public:
	 EventStartTurn();
};

#endif __START_TURN_EVENT_H__
