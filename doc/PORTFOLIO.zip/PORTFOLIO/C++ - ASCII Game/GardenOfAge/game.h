#ifndef __GAME_H__
#define __GAME_H__

class game {
public:
	static void start();
};

#endif __GAME_H__