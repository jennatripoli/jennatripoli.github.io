Sprite Resources:

(used as inspiration, no sprites were directly copied)

https://textart.io/art/tag/sword/1
https://www.asciiart.eu/weapons/shields
https://www.asciiart.eu/weapons/bows-and-arrows
https://www.asciiart.eu/clothing-and-accessories/crowns
https://www.asciiart.eu/mythology/ghosts
https://www.asciiart.eu/people/occupations/knights
https://www.asciiart.eu/people/occupations/wizards