#include "EventEndTurn.h"

EventEndTurn::EventEndTurn() {
  setType(END_TURN_EVENT);
};
