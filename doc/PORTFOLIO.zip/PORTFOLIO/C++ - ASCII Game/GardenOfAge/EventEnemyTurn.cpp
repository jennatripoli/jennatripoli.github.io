#include "EventEnemyTurn.h"

EventEnemyEndTurn::EventEnemyEndTurn() {
	setType(END_ENEMY_TURN_EVENT);
}
