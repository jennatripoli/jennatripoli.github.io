Sound Resources:

https://freesound.org/people/Raclure/sounds/458867/
https://freesound.org/people/Sheyvan/sounds/470083/
https://freesound.org/people/Xythe/sounds/516912/
https://freesound.org/people/Leszek_Szary/sounds/133283/
https://freesound.org/people/Sunsai/sounds/415805/