#include "EventStartTurn.h"

EventStartTurn::EventStartTurn() {
	setType(START_TURN_EVENT);
}
