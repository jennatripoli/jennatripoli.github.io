package Q1;

public class Speedrun implements Comparable<Speedrun> {
	private int time = 0;  // length in seconds of run
	
	public Speedrun(int time) {
		this.time = time;
	}

	public int compareTo(Speedrun a) {
		if (this.time > a.time) return 1;
		else if (this.time < a.time) return -1;
		else return 0;
	}
	
	public int getTime() { return time; }
}
