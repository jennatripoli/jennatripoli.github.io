import java.util.Arrays;
import java.util.Random;
import java.util.Stack;
import java.util.stream.IntStream;

import Q1.*;
import Q2.*;

public class Main {

	public static void main(String[] args) {
		question1();
		question2();
		
		/** EMPIRICAL COMPARISON FOR Q2:
		 * By running a stop watch while testing HeapSort, InsertionSort, and QuickSort,
		 * we can see that HeapSort and QuickSort are significantly faster than InsertionSort.
		 * The time complexity of InsertionSort is O(n^2) because of the nested for loop
		 * in the implementation. QuickSort and HeapSort take a very similar amount of time,
		 * but QuickSort is sometimes slightly faster than HeapSort because while HeapSort 
		 * will swap all of the elements in the array to order it correctly, QuickSort does not 
		 * swap as many elements (by partitioning the array).
		 */
	}
	
	/** run code for question 1 */
	public static void question1() {
		System.out.println("QUESTION 1");

		// sort an array of randomly-generated integers
		int[] A = IntStream.generate(() -> new Random().nextInt(1000)).limit(20).toArray();
		Integer[] Ai = Arrays.stream(A).boxed().toArray(Integer[]::new);  // convert to Integer[]

		MinPQ<Integer> pq = new MinPQ<Integer>(Ai.length + 1);  // priority queue
		for (Integer i : Ai) pq.insert(i);

		Stack<Integer> stack = new Stack<Integer>();
		while (!pq.isEmpty()) stack.push(pq.delMin());  // add all min to stack

		System.out.println("Randomly-generated integers: ");
		for (Integer i : stack) System.out.print(i + " ");  // print result
		System.out.println();
		
		// manually create an array of objects based on class from step 3 (Speedun)
		Speedrun[] B = { new Speedrun(10), new Speedrun(45), new Speedrun(6), new Speedrun(72),
				new Speedrun(33), new Speedrun(104), new Speedrun(89), new Speedrun(24) };
		
		MinPQ<Integer> pq2 = new MinPQ<Integer>(B.length + 1);  // priority queue
		for (Speedrun i : B) pq2.insert(i.getTime());
		
		Stack<Integer> stack2 = new Stack<Integer>();
		while (!pq2.isEmpty()) stack2.push(pq2.delMin());  // add all min to stack
		
		System.out.println("Manually-created speedrun times: ");
		for (Integer i : stack2) System.out.print(i + " ");  // print result
		
		System.out.print("\n\n");
	}
	
	/** run code for question 2 */
	public static void question2() {
		System.out.println("QUESTION 2");

		int[] A = IntStream.generate(() -> new Random().nextInt(10000)).limit(100000).toArray();
		Integer[] Ai = Arrays.stream(A).boxed().toArray(Integer[]::new);
		
		int[] B = IntStream.generate(() -> new Random().nextInt(10000)).limit(100000).toArray();
		Integer[] Bi = Arrays.stream(B).boxed().toArray(Integer[]::new);
		
		int[] C = IntStream.generate(() -> new Random().nextInt(10000)).limit(100000).toArray();
		Integer[] Ci = Arrays.stream(C).boxed().toArray(Integer[]::new);
		
		int[] D = IntStream.generate(() -> new Random().nextInt(100)).limit(20).toArray();
		Integer[] Di = Arrays.stream(D).boxed().toArray(Integer[]::new);
		
		// add unused 0 to beginning for HeapSort (newAi: for calculating elapsed time)
		Integer[] newAi = Arrays.copyOf(Ai, Ai.length + 1);
		newAi[0] = 0;
		System.arraycopy(Ai, 0, newAi, 1, Ai.length);
		
		// add unused 0 to beginning for HeapSort (newDi: for demonstrating functionality)
		Integer[] newDi = Arrays.copyOf(Di, Di.length + 1);
		newDi[0] = 0;
		System.arraycopy(Di, 0, newDi, 1, Di.length);
		
		// demonstrate functionality for HeapSort
		HeapSort.sort(newDi);
		System.out.println("Demonstrate HeapSort functionality (isSorted() == " + HeapSort.isSorted(newDi) + "):");
		for (Integer i : newDi) System.out.print(i + " ");  // print result
		System.out.println();
		
		// calculate elapsed time for HeapSort
		Stopwatch watch = new Stopwatch();  // initialize stop watch for all tests
		watch.start();
		HeapSort.sort(newAi);
		watch.stop();
		System.out.println("HeapSort Seconds Elapsed: " + watch.getElapsedSeconds());
		watch.reset();
		
		// calculate elapsed time for QuickSort
		watch.start();
		QuickSort.sort(Bi);
		watch.stop();
		System.out.println("QuickSort Seconds Elapsed: " + watch.getElapsedSeconds());
		watch.reset();
		
		// calculate elapsed time for InsertionSort
		watch.start();
		InsertionSort.sort(Ci);
		watch.stop();
		System.out.println("InsertionSort Seconds Elapsed: " + watch.getElapsedSeconds());
		watch.reset();
		
		System.out.print("\n");
	}
}