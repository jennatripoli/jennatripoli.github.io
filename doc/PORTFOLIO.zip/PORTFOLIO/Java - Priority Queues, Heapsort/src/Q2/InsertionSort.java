package Q2;

public class InsertionSort<Key extends Comparable<Key>> {
	
	/** sort arr[] into increasing order */
	public static void sort(Comparable[] arr) {
		int N = arr.length;
		for (int i = 1; i < N; i++) {  // insert a[i] among a[i-1], a[i-2], a[i-3]...
			for (int j = i; j > 0 && less(arr[j], arr[j-1]); j--) {
				exch(arr, j, j-1);
			}
		}
	}

	private static boolean less(Comparable v, Comparable w) {
		return v.compareTo(w) < 0;
	}

	private static void exch(Comparable arr[], int i, int j) {
		Comparable t = arr[i];
		arr[i] = arr[j];
		arr[j] = t;
	}
}
