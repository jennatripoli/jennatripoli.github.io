package Q2;

import java.util.Arrays;

public class HeapSort<Key extends Comparable<Key>> {
	
	/** sort a[] into increasing order */
	public static void sort(Comparable[] arr) {
		int N = arr.length - 1;
		for (int k = N / 2; k >= 1; k--) sink(arr, k, N);
		while (N > 1) {
			exch(arr, 1, N--);
			sink(arr, 1, N);
		}
	}

	/** integrate a[] into compare */
	private static boolean less(Comparable arr[], int i, int j) {
		return arr[i].compareTo(arr[j]) < 0;
	}

	/** integrate a[] into exch */
	private static void exch(Comparable arr[], int i, int j) {
		Comparable t = arr[i];
		arr[i] = arr[j];
		arr[j] = t;
	}

	/** integrate a[] and N into sink */
	private static void sink(Comparable arr[], int k, int N) {
		while (2 * k <= N) {
			int j = 2 * k;
			if (j < N && less(arr, j, j + 1)) j++;
			if (!less(arr, k, j)) break;
			exch(arr, k, j);
			k = j;
		}
	}

	/** test whether the array entries are in order */
	public static boolean isSorted(Comparable[] arr) {
		for (int i = 1; i < arr.length; i++) {
			if (less(arr, i, i-1)) return false;
		}
		return true;
	}
}
