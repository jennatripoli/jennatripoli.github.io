package Q2;

public class Stopwatch {
	private long start, end;
	
	public Stopwatch() {
		start = 0;
		end = 0;
	}
	
	public void start() {
		start = System.currentTimeMillis();
	}
	
	public void stop() {
		end = System.currentTimeMillis();
	}
	
	public void reset() {
		start = 0;
		end = 0;
	}
	
	public double getElapsedSeconds() {
		return (end - start) / 1000.0;
	}
}
