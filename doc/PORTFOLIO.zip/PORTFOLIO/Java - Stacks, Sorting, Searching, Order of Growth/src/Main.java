import java.util.Random;
import java.util.stream.IntStream;

import Q1.StackCalculator;
import Q2.BinaryRecursiveSearch;
import Q2.BinarySearch;
import Q2.LinearSearch;
import Q3.Question3;
import Q5.BubbleSort;
import Q5.MergeSort;
import Q5.QuickSort;

public class Main {
	static StackCalculator stackulator;

	public static void main(String[] args) {
		/* INSTRUCTIONS: To compile the code for a certain question,
		 * un-comment the line below that corresponds to the name of
		 * the question. For example, to run the code for question 3,
		 * uncomment the line that says "question3();" */
		question1();
		question2();
		question3();
		question5();
	}
	
	/* Method to run Question 1. */
	public static void question1() {
		System.out.println("QUESTION 1");
		StackCalculator.examples();
		System.out.print("\n");
	}
	
	/* Method to run Question 2. */
	public static void question2() {
		System.out.println("QUESTION 2");
		LinearSearch.printAvg();
		BinarySearch.printAvg();
		BinaryRecursiveSearch.printAvg();
		System.out.print("\n");
	}
	
	/* Method to run Question 3. */
	public static void question3() {
		System.out.println("QUESTION 3");
		int[] inputArr = IntStream.generate(() -> new Random().nextInt(100)).limit(100000).toArray();
		int[] inputArrSmall = IntStream.generate(() -> new Random().nextInt(100)).limit(1000).toArray();
		Question3.linear(inputArr);
		Question3.quadratic(inputArr);
		// AlgorithmEfficiency.cubic(inputArr);  // takes too long
		Question3.cubic(inputArrSmall);  // used for calculations
		System.out.print("\n");
	}
	
	/* Method to run Question 5. */
	public static void question5() {
		System.out.println("QUESTION 5");
		BubbleSort.printAvg();
		MergeSort.printAvg();
		QuickSort.printAvg();
		System.out.print("\n");
	}
}
