package Q3;

public class Question3 {

	/**
	 * Does one loop over input array and prints elapsed time in seconds.
	 * @param arr input array
	 */
	public static void linear(int[] arr) {
		double start = System.currentTimeMillis(), end = 0;
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			sum += i;
		}
		end = System.currentTimeMillis();
		System.out.println("Linear Function Elapsed Time: " + (end - start) / 1000);
	}
	
	/**
	 * Does two loops (nested) over input array and prints elapsed time in seconds.
	 * @param arr input array
	 */
	public static void quadratic(int[] arr) {
		double start = System.currentTimeMillis(), end = 0;
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				sum += j;
			}
		}
		end = System.currentTimeMillis();
		System.out.println("Quadratic Function Elapsed Time: " + (end - start) / 1000);
	}
	
	/**
	 * Does three loops (nested) over input array and prints elapsed time in seconds.
	 * @param arr input array
	 */
	public static void cubic(int[] arr) {
		double start = System.currentTimeMillis(), end = 0;
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				for (int k = 0; k < arr.length; k++) {
					k++;
				}
			}
		}
		end = System.currentTimeMillis();
		System.out.println("Cubic Function Elapsed Time: " + (end - start) / 1000);
	}
}
