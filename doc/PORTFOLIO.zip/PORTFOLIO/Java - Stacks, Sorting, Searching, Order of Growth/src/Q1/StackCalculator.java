package Q1;
import java.util.Stack;

public class StackCalculator {
	
	/**
	 * Calculate the value of a mathematical expression using a Stack and print to the console.
	 * Modification: added sin, cos, and tan operations.
	 * @param input expression to calculate as a String. Put a space between each character.
	 */
	public static void calculate(String input) {
		Stack<String> ops  = new Stack<String>();
        Stack<Double> vals = new Stack<Double>();
        String[] expression = input.split(" ");
        
        for (String item : expression) {
        	if (item.equals("(")) ops.push(item);
	        else if (item.equals("+")) ops.push(item);
	        else if (item.equals("-")) ops.push(item);
	        else if (item.equals("*")) ops.push(item);
	        else if (item.equals("/")) ops.push(item);
	        else if (item.equals("sqrt")) ops.push(item);
	        else if (item.equals("sin")) ops.push(item);
	        else if (item.equals("cos")) ops.push(item);
	        else if (item.equals("tan")) ops.push(item);
        	
	        else if (item.equals(")")) {  // pop, evaluate, and push result if token is ")"
	        	String op = ops.pop();
	        	double v = vals.pop();
	        	if (op.equals("+")) v = vals.pop() + v;
	        	else if (op.equals("-")) v = vals.pop() - v;
	        	else if (op.equals("*")) v = vals.pop() * v;
	        	else if (op.equals("/")) v = vals.pop() / v;
	        	else if (op.equals("sqrt")) v = Math.sqrt(v);
	        	else if (op.equals("sin")) v = Math.sin(v);
	        	else if (op.equals("cos")) v = Math.cos(v);
	        	else if (op.equals("tan")) v = Math.tan(v);
	        	vals.push(v);
	        }
        	
	        else if (item.equals("")) {}
	        else vals.push(Double.parseDouble(item));  // token not operator or parenthesis: push double value
        }
        
        System.out.println(vals.pop());
	}
	
	public static void examples() {
		// expressions that show functionality
		System.out.println("Expressions that Show Functionality:");

		System.out.print("( ( 4 + 1 ) + 3 ) = ");
		calculate("( ( 4 + 1 ) + 3 )");

		System.out.print("( ( 8 - 2 ) / 2 ) = ");
		calculate("( ( 8 - 2 ) / 2 )");

		System.out.print("( ( 9 * 3 ) - 8 ) = ");
		calculate("( ( 9 * 3 ) - 8 )");

		System.out.print("( ( 5 / 2 ) * 4 ) = ");
		calculate("( ( 5 / 2 ) * 4 )");

		System.out.print("( sqrt ( 9 ) ) = ");
		calculate("( sqrt ( 9 ) )");

		System.out.print("( 11 + 5 ) = ");
		calculate("( 11 + 5 )");

		// expressions with new operations
		System.out.println("Expressions with New Operations:");

		System.out.print("( ( sin ( 3 ) ) - 1 ) = ");
		calculate("( ( sin ( 3 ) ) - 1 )");

		System.out.print("( ( cos ( 2 + 2 ) ) ) = ");
		calculate("( ( cos ( 2 + 2 ) ) )");

		System.out.print("( ( tan ( 1 - 9 ) ) ) = ");
		calculate("( ( tan ( 1 - 9 ) ) )");

		// expressions that do not work
		System.out.println("Expressions that Don't Work:");

		System.out.print("4 + 2 = ");
		calculate("4 + 2");  // missing surrounding parentheses
		System.out.print("( sqrt ( 4 + 5 ) ) = ");
		calculate("( sqrt ( 4 + 5 ) )");  // missing extra parentheses around operations with parameters
		// stackulator.calculate("(5*4)");  // missing spaces between items (commented out due to errors)
	}
}
