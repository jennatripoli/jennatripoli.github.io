package Q2;
import java.util.Random;
import java.util.stream.IntStream;

public class BinaryRecursiveSearch {
	public static int steps = 0;
	
	public static int search(int key, int[] arr) {
		steps = 0;		
		return search(key, arr, 0, arr.length - 1);
	}
	
	public static int search(int key, int[] arr, int low, int high) {
		/* STEP COUNT: This placement of the increase of the step counter is
		 * important to note because it is within the method that is being
		 * called recursively, not the method that is being called when the
		 * array is being searched through initially. This method does a very
		 * similar process to the one in BinarySearch, where the key is compared
		 * to the middle of the array. This method is called again until the
		 * key is found in the middle point of the array, which is all a singular
		 * step in searching through the array. */
		steps++;
		int mid = low + (high - low) / 2;

		if (low > high) return -1;
		else if (key > arr[mid]) return search(key, arr, mid + 1, high);
		else if (key < arr[mid]) return search (key, arr, low, mid - 1);
		else return mid;
	}
	
	public static void printAvg() {
		System.out.println("Average Steps in Binary Recursive Search:");
		calculateAvg(100);
		calculateAvg(1000);
		calculateAvg(10000);
		calculateAvg(100000);
		calculateAvg(250000);
	}
	
	private static void calculateAvg(int size) {
		int stepsTotal = 0;
		int[] randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		int[] candidates = IntStream.generate(() -> new Random().nextInt(100)).limit(1).toArray();

		search(candidates[0], randomInts);
		stepsTotal += steps;
		randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		search(candidates[0], randomInts);
		stepsTotal += steps;
		randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		search(candidates[0], randomInts);
		stepsTotal += steps;
		System.out.format(size + ": %d\n", stepsTotal / 3);
	}
}
