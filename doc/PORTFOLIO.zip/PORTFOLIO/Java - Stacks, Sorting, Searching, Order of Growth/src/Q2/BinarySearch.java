package Q2;
import java.util.Random;
import java.util.stream.IntStream;

public class BinarySearch {
	public static int steps = 0;
	
	public static int search(int key, int[] arr) {
		steps = 0;
		int low = 0, high = arr.length - 1, mid;
		
		while (low <= high) {
			/* STEP COUNT: This while loop encompasses all operations that will be
			 * done on the input array. It checks the value of the key against the
			 * middle value of the array, which is a singular step in the array.
			 * Therefore, this is a good location for an increase to the step count. */
			steps++;
			mid = low + (high - low) / 2;
			
			if (key > arr[mid]) low = mid + 1;
			else if (key < arr[mid]) high = mid - 1;
			else return mid;
		} 
		return -1;
	}
	
	public static void printAvg() {
		System.out.println("Average Steps in Binary Search:");
		calculateAvg(100);
		calculateAvg(1000);
		calculateAvg(10000);
		calculateAvg(100000);
		calculateAvg(250000);
	}
	
	private static void calculateAvg(int size) {
		int stepsTotal = 0;
		int[] randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		int[] candidates = IntStream.generate(() -> new Random().nextInt(100)).limit(1).toArray();

		search(candidates[0], randomInts);
		stepsTotal += steps;
		randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		search(candidates[0], randomInts);
		stepsTotal += steps;
		randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		search(candidates[0], randomInts);
		stepsTotal += steps;
		System.out.format(size + ": %d\n", stepsTotal / 3);
	}
}
