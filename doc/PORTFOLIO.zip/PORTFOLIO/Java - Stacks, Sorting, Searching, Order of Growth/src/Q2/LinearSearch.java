package Q2;
import java.util.Random;
import java.util.stream.IntStream;

public class LinearSearch {
	public static int steps = 0;
	
	public static int search(int key, int[] arr) {
		steps = 0;
		
		for (int i = 0; i < arr.length; i++) {
			/* STEP COUNT: This for loop iterates through every element in the
			 * array until the search is complete. The number of operations 
			 * completed corresponds to the number of elements the algorithm
			 * iterated through to find the key, so this location makes sense 
			 * for an increase to the step count to be placed. */
			steps++;
			if (arr[i] == key) return i;
		}
		return -1;
	}
	
	public static void printAvg() {
		System.out.println("Average Steps in Linear Search:");
		calculateAvg(100);
		calculateAvg(1000);
		calculateAvg(10000);
		calculateAvg(100000);
		calculateAvg(250000);
	}
	
	private static void calculateAvg(int size) {
		int stepsTotal = 0;
		int[] randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		int[] candidates = IntStream.generate(() -> new Random().nextInt(100)).limit(1).toArray();

		search(candidates[0], randomInts);
		stepsTotal += steps;
		randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		search(candidates[0], randomInts);
		stepsTotal += steps;
		randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		search(candidates[0], randomInts);
		stepsTotal += steps;
		System.out.format(size + ": %d\n", stepsTotal / 3);
	}
}
