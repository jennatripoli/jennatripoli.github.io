package Q5;
import java.util.Random;
import java.util.stream.IntStream;

public class MergeSort {
	public static long steps = 0;

	public static void sort(int[] arr) {
		steps = 0;
		sort(arr, 0, arr.length - 1);
	}
	
	private static void sort(int[] arr, int low, int high) {
		/* STEP COUNT: This location is important to increasing the step count
		 * because this method is called recursively to iterate through the list.
		 * At each of these iterations, various processes are done, but the overall
		 * step in through the array to get to this location with the recursive call
		 * should be counted here. */
		steps++;
		int mid = low + (high - low) / 2;
		if (high <= low) return;
		sort(arr, low, mid);
		sort(arr, mid + 1, high);
		merge(arr, low, mid, high);
	}
	
	private static void merge(int[] arr, int low, int mid, int high) {
		int i = low, j = mid + 1;
		int[] aux = new int[arr.length];
		
		for (int k = low; k <= high; k++) aux[k] = arr[k];
		for (int k = low; k <= high; k++) {
			/* STEP COUNT: The step count should be increased here because
			 * this method is doing operations on the current value in the array
			 * and is called after sort is called, so it must be included in the
			 * counting of steps. */
			steps++;
			if (i > mid) arr[k] = aux[j++];
			else if (j > high) arr[k] = aux[i++];
			else if (less(aux[j], aux[i])) arr[k] = aux[j++];
			else arr[k] = aux[i++];
		}
	}
	
	private static boolean less(Integer v, Integer w) {
		return v.compareTo(w) < 0;
	}
	
	public static void printAvg() {
		System.out.println("Average Steps in Merge Sort:");
		calculateAvg(100);
		calculateAvg(1000);
		calculateAvg(10000);
		calculateAvg(100000);
		calculateAvg(250000);
	}
	
	private static void calculateAvg(int size) {
		long stepsTotal = 0;
		int[] randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		sort(randomInts);
		stepsTotal += steps;
		randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		sort(randomInts);
		stepsTotal += steps;
		randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		sort(randomInts);
		stepsTotal += steps;
		System.out.format(size + ": %d\n", stepsTotal / 3);
	}
}
