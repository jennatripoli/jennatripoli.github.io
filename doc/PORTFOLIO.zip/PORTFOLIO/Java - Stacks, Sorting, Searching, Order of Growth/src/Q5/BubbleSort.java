package Q5;
import java.util.Random;
import java.util.stream.IntStream;

public class BubbleSort {
	public static long steps = 0;
	
	public static void sort(int arr[]) {
		steps = 0;
		
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = 0; j < arr.length - i - 1; j++) {
				/* STEP COUNT: The number of steps is increased here in the nested for loop
				 * because this is where the operations on the array are done. The current
				 * element in the array is tested to see if it is greater than the element
				 * adjacent to it to the right, and if this is the case, the elements will
				 * switch locations. This check is the only real step in the array, so it is
				 * where the step count is increased. */
				steps++;
				if (arr[j] > arr[j + 1]) {
					int temp = arr[j + 1];
					arr[j + 1] = arr[j];
					arr[j] = temp;
				}
			}
		}
	}
	
	public static void printAvg() {
		System.out.println("Average Steps in Bubble Sort:");
		calculateAvg(100);
		calculateAvg(1000);
		calculateAvg(10000);
		calculateAvg(100000);
		calculateAvg(250000);
	}
	
	private static void calculateAvg(int size) {
		long stepsTotal = 0;
		int[] randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		sort(randomInts);
		stepsTotal += steps;
		randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		sort(randomInts);
		stepsTotal += steps;
		randomInts = IntStream.generate(() -> new Random().nextInt(100)).limit(size).toArray();
		sort(randomInts);
		stepsTotal += steps;
		System.out.format(size + ": %d\n", stepsTotal / 3);
	}
}
