In project 3 we created a memory allocator called the Gompei Allocator. It reserves an area in memory called the arena
from which the Gompei Allocator can allocate memory. The arena is created using the function init() and is destroyed 
using the function destroy(). Allocating memory is done with the function walloc() and freeing memory is done using 
the wfree() function. Each reserved piece of memory is called a chunk. Each chunk has a header with metadata and space
where data can be stored. The metadata includes a chunk's size, its availability (is_free), and pointers to the chunks
before and after the given chunk. When reserving memory in a chunk, the allocator must account for the fact that
headers take up space. The allocator also must split chunks that leave extra space unused so that space can be 
utilized later on. Allocations also have to be in increasing order in terms of address in the arena. In the case where
a chunk is freed while an adjacent chunks is also free, the two free chunks must be combined allowing for larger 
pieces of data can be stored. If a chunk is freed and both the chunks in front and behind it are free, all three must 
be condensed into one free chunk (chaining). 
