#include "gompeimalloc.h"
#include <sys/mman.h>
#include <fcntl.h>
#include <stddef.h>
#include <stdio.h>
#include <unistd.h>
#include <stdbool.h>

void *_arena_start;   // pointer to start of arena
void *_arena_end;     //pointer to end of arena
size_t arena_size;    // size of arena, in bytes
bool initErr = true;  // used as flag for if init() was successful
node_t *listHead;     // node for start of arena
int statusno;         // used to see what error occured
size_t sizeUsed;      // keeps track of the size used in the arena

// initialize the memory allocator of (size) bytes
extern int init(size_t size) {
    sizeUsed = 0;
    initErr = false;
    if((int)size < 0) {
        initErr = true;  // init() returned an error
        return ERR_BAD_ARGUMENTS;
    }

    printf("Initializing arena:\n");
    int fd = open("/dev/zero", O_RDWR);
    size_t page_size = getpagesize();

    printf("...requested size %ld bytes\n", size);
    printf("...pagesize is %ld bytes\n", page_size);

    printf("...adjusting size with page boundaries\n");
    // if size is greater than page_size, set arena_size to (size / page_size) to the nearest factor of page_size, rounded up
    if(size > page_size) arena_size = page_size * (size / page_size + 1);
    // if size is less than or equal to page_size, set arena_size to page_size
    else arena_size = page_size;
    printf("...adjusted size is %ld\n", arena_size);

    printf("...mapping arena with mmap()\n");
    // request a region of memory for arena
    _arena_start = mmap(NULL, arena_size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    printf("...arena starts at %p\n",_arena_start);

    //stets arena end variable
    _arena_end = (void*) (((char*) _arena_start) + size);
    printf("...arena ends at %p\n",_arena_end);

    printf("...initializing header for initial free chunk\n");
    listHead = (node_t *) _arena_start;
    listHead->is_free = 1;  // not being used
    listHead->fwd = NULL;   // node before
    listHead->bwd = NULL;   // node after
    listHead->size = arena_size - sizeof(node_t);
    printf("...header size is %ld\n", sizeof(node_t));

    return arena_size;
}

// return arena's memory to OS and reset all internal state variables
extern int destroy() {
    // if init() was not successful, return ERR_UNITIALIZED
    if(initErr) {
        printf("...error: cannot destroy uninitialized arena. Setting error status\n");
        return ERR_UNINITIALIZED;
    }

    printf("Destroying arena\n");
    printf("unmapping arena with munmap()\n");
    return munmap(_arena_start, arena_size);
}


// request a new memory allocation of (size) bytes
extern void* walloc(size_t size){
    // if init() was not successful, return NULL and set error flag to ERR_UNITIALIZED
    if(initErr) {
        printf("Error: Uninitialized. Setting status code\n");
        statusno = ERR_UNINITIALIZED;
        return NULL;
    }

    // set current head to start of arena and make temp node
    node_t *curNode = _arena_start;
    node_t *temp;

    printf("Allocating memory:\n");
    printf("...looking for a free chunk of >= %ld bytes\n", size);

    // check for free chunks in arena
    while(curNode != NULL) {
        //If there is no memory left set error flag
        if(sizeUsed>=arena_size) {
            statusno = ERR_OUT_OF_MEMORY;
            return NULL;
        }

        // if the current node is not being used, and it can fit (size + header node), free chunk is found
        if(curNode->is_free == 1 && curNode->size >= size) {
            printf("...found a free chunk of %ld bytes with header at %p\n", size, curNode);

            //print fwd and bwd chunks
            printf("...free chunk->fwd currently points to %p\n",curNode->fwd);
            printf("...free chunk->bwd  currently points to %p\n",curNode->bwd);

            printf("...checking if splitting is required\n");

            // only splits when there is enough room for node
            if(curNode->size - size > sizeof(node_t)) {
                // set curNode size and is_free, increment sizeUsed
                curNode->size = size;
                sizeUsed += size;
                curNode->is_free = 0;

                // make new node for split and set its variables
                node_t *splitNode = (void*) ((char*)curNode) + sizeof(node_t) + size;
                sizeUsed += sizeof(node_t);
                splitNode->size = (arena_size - sizeof(node_t)) - sizeUsed;
                splitNode->is_free = 1;

                //Set fwd and bwd for curNode and splitNode
                splitNode->fwd = curNode->fwd;
                splitNode->bwd = curNode;
                curNode->fwd = splitNode;

                printf("...being careful with my pointer arithmetic and void pointer casting\n");
                printf("...allocation starts at %p\n", (void*) (((char*) curNode) + sizeof(node_t)));
                return (void*) ((char*)curNode) + sizeof(node_t);
            }

            // splitting is not required
            else {
                printf("...splitting not required\n");
                printf("...updating chunk header at %p\n", curNode);

                // update current node
                sizeUsed += size;
                curNode->is_free = 0;

                printf("...being careful with my pointer arithmetic and void pointer casting\n");
                printf("...allocation starts at %p\n", (void*) (((char*) curNode) + sizeof(node_t)));

                return (void*) ((char*)curNode) + sizeof(node_t);
            }
        }

        // if on last node and there is not enough memory, set error
        if(curNode->fwd ==NULL && size > curNode->size) statusno = ERR_OUT_OF_MEMORY;

        // when not able to allocate, move to next node
        temp = curNode->fwd;
        curNode = temp;
    }

    // when unable to allocate in arena
    printf("...no such free chunk exists\n");
    printf("...setting error code \n");
    statusno = ERR_OUT_OF_MEMORY;
    return NULL;
}

extern void wfree(void *ptr) {
    bool fwdNull, bwdNull;
    printf("Freeing allocated memory:\n");
    printf("...supplied pointer %p\n", ptr);
    printf("...being careful wit my pointer arithmetic and void pointer casting\n");
    printf("...accessing chunk header at %p\n", (void*) ((char*)ptr) - sizeof(node_t));
    node_t *node = (void*) ((char*)ptr) - sizeof(node_t);
    printf("...chunk of size %ld\n", node->size);
    node->is_free = 1;  // set node to free

    printf("...checking if coalescing is needed\n");
    // used to check if fwd / bwd nodes are NULL
    fwdNull = node->fwd == NULL;
    bwdNull = node->bwd == NULL;

    // coalesces start of arena with node ahead
    if(bwdNull && !fwdNull && node->fwd->is_free == 1) {
        printf("col. case: start of arena is freed.\n");
        node->size += node->fwd->size + sizeof(node_t);
        node->fwd = node->fwd->fwd;
    }

    // coalesces end of arena with adjacent node
    else if(fwdNull && !bwdNull && node->bwd->is_free==1){
        printf("col. case: end of arena is freed\n");
        node->bwd->size += node->size + sizeof(node_t);
        node->bwd->fwd = node->fwd;
    }

    // fwd and bwd are free (chaining)
    else if(!fwdNull && !bwdNull && node->fwd->is_free == 1 && node->bwd->is_free == 1){
        printf("col. case: fwd and bwd chunks must be combined with current chunk\n");
        node->bwd->size += node->size + node->fwd->size + 2*sizeof(node_t);
        node->bwd->fwd = node->fwd->fwd;
    }

    // behind chunk is free
    else if(!bwdNull && node->bwd->is_free==1){
        printf("col. case: combine wth chunk behind\n");
        node->bwd->size += node->size + sizeof(node_t);
        node->bwd->fwd = node->fwd;
        node->fwd->bwd = node->bwd;
    }

    // infront chunk is free
    else if(!fwdNull && node->fwd->is_free==1){
        printf("col. case: combine wth chunk infront\n");
        node->size += node->fwd->size + sizeof(node_t);
        node->fwd = node->fwd->fwd;
    }

    // no need to coalesce
    else printf("...coalescing not needed\n");
}
