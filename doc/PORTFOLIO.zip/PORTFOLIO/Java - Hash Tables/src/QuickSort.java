
public class QuickSort {
	
	/** sort a[] into increasing order */
	public static void sort(Comparable[] arr) {
		sort(arr, 0, arr.length - 1);
	}
	
	/** sort a[] into increasing order, used recursively */
	public static void sort(Comparable[] arr, int low, int high) {
		if (high <= low) return;
		int j = partition(arr, low, high);
		sort(arr, low, j - 1);
		sort(arr, j + 1, high);
	}
	
	public static int partition(Comparable[] arr, int low, int high) {
		int i = low, j = high + 1;
		Comparable v = arr[low];
		
		while (true) {
			while (less(arr[++i], v)) {
				if (i == high) break;
			}
			while (less(v, arr[--j])) {
				if (j == low) break;
			}
			if (i >= j) break;
			
			exch(arr, i, j);
		}
		
		exch(arr, low, j);
		return j;
	}
	
	public static boolean less(Comparable v, Comparable w) {
		return v.compareTo(w) < 0;
	}
	
	public static void exch(Comparable arr[], int i, int j) {
		Comparable t = arr[i];
		arr[i] = arr[j];
		arr[j] = t;
	}
}
