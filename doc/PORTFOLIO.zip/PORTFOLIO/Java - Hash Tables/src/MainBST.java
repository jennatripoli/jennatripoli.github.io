import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

public class MainBST {
	private static LinkedList<BST<String, Term>> fileListBST;
	private static BST<String, Term> docFreqBST, file1, file2, file3, file4, file5, file6, file7, file8, file9, file10, file11, file12, file13, file14;
	
	/** read in files and create a hash table for each document */
	public static void setup() {
		fileListBST = new LinkedList<BST<String, Term>>();
		
		docFreqBST = readIn("src/data/allCatPoems.txt");  // all words in all documents
		file1 = readIn("src/data/bustopher-jones-the-cat-about-town.txt");
		file2 = readIn("src/data/growltigers-last-stand.txt");
		file3 = readIn("src/data/gus-the-theater-cat.txt");
		file4 = readIn("src/data/macavity-the-mystery-cat.txt");
		file5 = readIn("src/data/mr-mistoffelees.txt");
		file6 = readIn("src/data/mungojerrie-and-rumpelteazer.txt");
		file7 = readIn("src/data/of-the-awefull-battle-of-the-pekes-and-the-pollicles.txt");
		file8 = readIn("src/data/old-deuteronomy.txt");
		file9 = readIn("src/data/skimbleshanks-the-railway-cat.txt");
		file10 = readIn("src/data/the-ad-dressing-of-cats.txt");
		file11 = readIn("src/data/the-naming-of-cats.txt");
		file12 = readIn("src/data/the-old-gumbie-cat.txt");
		file13 = readIn("src/data/the-rum-tum-tugger.txt");
		file14 = readIn("src/data/the-song-of-the-jellicles.txt");

		fileListBST.add(file1);
		fileListBST.add(file2);
		fileListBST.add(file3);
		fileListBST.add(file4);
		fileListBST.add(file5);
		fileListBST.add(file6);
		fileListBST.add(file7);
		fileListBST.add(file8);
		fileListBST.add(file9);
		fileListBST.add(file10);
		fileListBST.add(file11);
		fileListBST.add(file12);
		fileListBST.add(file13);
		fileListBST.add(file14);
	}
	
	/** calculate tf, idf, and tf-idf (method c) for each document */
	public static void calculateTF_IDF() {
		for (int i = 0; i < fileListBST.size(); i++) {
			for (Term term : fileListBST.get(i).valLevelOrder()) {
				if (term != null) {
					term.tf = Math.log(1 + term.frequency);
					term.idf = Math.log(fileListBST.size() / countOccurances(term));
					term.tf_idf = term.tf * term.idf;
				}
			}
			
			// calculate for all words in all documents (docFreqBST)
			for (Term term : docFreqBST.valLevelOrder()) {
				if (term != null) {
					term.tf = Math.log(1 + term.frequency);
					term.idf = Math.log(fileListBST.size() / countOccurances(term));
					term.tf_idf = term.tf * term.idf;
				}
			}
		}
	}
	
	/** count the number of documents the term occurs in 
	 *  @param term (the term to count occurrences of) 
	 *  @return the number of documents the term occurs in */
	public static int countOccurances(Term term) {
		int a = 0;
		for (BST<String, Term> file : fileListBST) {
			if (file.contains(term.word)) a++;
		} return a;
	}
	
	/** print to the console the documents that contain a certain word,
	 * the frequency of the word in each document, and the tf-idf score
	 * @param key (word to search for, as a String) */
	public static void search(String key) {
		boolean found = false;
		System.out.println("SEARCH KEY: " + key);
		for (BST<String, Term> file : fileListBST) {
			if (file.contains(key)) {
				found = true;
				System.out.println("  DOCUMENT: " + file.get(key).document.substring(9) +
						"\n    FREQUENCY: " + file.get(key).frequency +
						"\n    TF-IDF: " + file.get(key).tf_idf);
			}
		}
		
		if (!found) System.out.println("  NOT PRESENT IN ANY DOCUMENTS");
		System.out.println();
	}
	
	/** read in plain text files and create a bst that stores a key and a term
	 * @param fileName (path of file to be read in, as a String)
	 * @return bst that contains the key and term for the file */
	public static BST<String, Term> readIn(String fileName) {
		BST<String, Term> table = new BST<String, Term>();
		LinkedList<String> arr = new LinkedList<String>();
		Scanner scanner;
		
		try {
			scanner = new Scanner(new File(fileName));
			while (scanner.hasNext())
	            arr.add(Arrays.toString(scanner.next().replaceAll("'", "").replaceAll("-", "").split("[\\s\\p{Punct}]+")));
			
			for (String a : arr) {
				if (!table.contains(a)) table.put(a, new Term(a, fileName, 1));
				else table.put(a, new Term(a, fileName, table.get(a).frequency + 1));
			} scanner.close();
			
		} catch (FileNotFoundException e) { e.printStackTrace(); }
		return table;
	}
	
	/** conduct an empirical evaluation of the search method, using random keys
	 * and testing search performance on a test set ten times with a stop watch
	 * @param randWords (random keys to search for, as a LinkedList)
	 * @return the time, in ms, that each test set took to search */
	public static LinkedList<Double> searchEval(LinkedList<String> randWords) {
		LinkedList<Double> times = new LinkedList<Double>();
		Stopwatch watch = new Stopwatch();
		
		for (int i = 1; i <= 10; i++) {
			watch.start();
			for (String word : randWords) search(word);
			watch.stop();
			times.add(watch.getElapsedMS());
			watch.reset();
		}
		return times;
	}
	
	/** conduct an empirical evaluation of the construction of the bst 
	 * for one file and print the time, in ms, to the console */
	public static void constructionEval() {
		Stopwatch watch = new Stopwatch();
		watch.start();
		readIn("src/data/bustopher-jones-the-cat-about-town.txt");
		watch.stop();
		System.out.println("BST CONSTRUCTION EMPERICAL EVALUATION:\n  " + watch.getElapsedMS() + " ms\n");
		watch.reset();
	}
}
