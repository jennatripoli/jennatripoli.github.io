import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {
	private static LinkedList<LinearProbingHashST<String, Term>> fileList;
	private static LinearProbingHashST<String, Term> docFreq, file1, file2, file3, file4, file5, file6, file7, file8, file9, file10, file11, file12, file13, file14;

	public static void main(String[] args) {
		taskSet1();
		taskSet2();
		//taskSet3();
		
		/** taskSet3() runs searchEval(). This runs search, which prints the search key, 
		 * document name, frequency of key, and tf-idf score. However, searchEval() 
		 * uses 1/10 of the total keys, which causes the beginning values written to 
		 * the console to be discarded. Therefore, I have left the code to test task 
		 * set 3 commented out, in order to show functionality for task sets 1 and 2.
		 * Uncomment line 14 to run the code for that part of the assignment. */
	}
	
	public static void taskSet1() {
		setup();
		calculateTF_IDF();
	}
	
	public static void taskSet2() {
		// demonstrate functionality of search
		search("[tell]");
		search("[because]");
		search("[wow]");
		
		// demonstrate functionality of top10
		System.out.println("TOP10: bustopher-jones-the-cat-about-town.txt");
		top10(fileList.get(0));
		System.out.println("TOP10: growltigers-last-stand.txt");
		top10(fileList.get(1));
		System.out.println("TOP10: gus-the-theater-cat.txt");
		top10(fileList.get(2));
	}
	
	public static void taskSet3() {
		MainBST.setup();
		MainBST.calculateTF_IDF();
		LinkedList<String> words = searchEvalList();
		LinkedList<Double> times = searchEval(words);
		LinkedList<Double> timesBST = MainBST.searchEval(words);
		
		// empirical evaluations of search
		System.out.println("SEARCH EMPERICAL EVALUATION:");
		for (int i = 0; i < times.size(); i++)
			System.out.println("  Test " + (i + 1) + ": " + times.get(i) + " ms");
		System.out.println();
		
		System.out.println("BST SEARCH EMPERICAL EVALUATION:");
		for (int i = 0; i < timesBST.size(); i++)
			System.out.println("  Test " + (i + 1) + ": " + timesBST.get(i) + " ms");
		System.out.println();
		
		// empirical evaluations of construction
		constructionEval();
		MainBST.constructionEval();
	}
	
	/** read in files and create a hash table for each document */
	public static void setup() {
		fileList = new LinkedList<LinearProbingHashST<String, Term>>();
		
		docFreq = readIn("src/data/allCatPoems.txt");  // all words in all documents
		file1 = readIn("src/data/bustopher-jones-the-cat-about-town.txt");
		file2 = readIn("src/data/growltigers-last-stand.txt");
		file3 = readIn("src/data/gus-the-theater-cat.txt");
		file4 = readIn("src/data/macavity-the-mystery-cat.txt");
		file5 = readIn("src/data/mr-mistoffelees.txt");
		file6 = readIn("src/data/mungojerrie-and-rumpelteazer.txt");
		file7 = readIn("src/data/of-the-awefull-battle-of-the-pekes-and-the-pollicles.txt");
		file8 = readIn("src/data/old-deuteronomy.txt");
		file9 = readIn("src/data/skimbleshanks-the-railway-cat.txt");
		file10 = readIn("src/data/the-ad-dressing-of-cats.txt");
		file11 = readIn("src/data/the-naming-of-cats.txt");
		file12 = readIn("src/data/the-old-gumbie-cat.txt");
		file13 = readIn("src/data/the-rum-tum-tugger.txt");
		file14 = readIn("src/data/the-song-of-the-jellicles.txt");

		fileList.add(file1);
		fileList.add(file2);
		fileList.add(file3);
		fileList.add(file4);
		fileList.add(file5);
		fileList.add(file6);
		fileList.add(file7);
		fileList.add(file8);
		fileList.add(file9);
		fileList.add(file10);
		fileList.add(file11);
		fileList.add(file12);
		fileList.add(file13);
		fileList.add(file14);
	}
	
	/** calculate tf, idf, and tf-idf (method c) for each document */
	public static void calculateTF_IDF() {
		for (int i = 0; i < fileList.size(); i++) {
			for (Term term : fileList.get(i)) {
				if (term != null) {
					term.tf = Math.log(1 + term.frequency);
					term.idf = Math.log(fileList.size() / countOccurances(term));
					term.tf_idf = term.tf * term.idf;
				}
			}
			
			// calculate for all words in all documents (docFreq)
			for (Term term : docFreq) {
				if (term != null) {
					term.tf = Math.log(1 + term.frequency);
					term.idf = Math.log(fileList.size() / countOccurances(term));
					term.tf_idf = term.tf * term.idf;
				}
			}
		}
	}
	
	/** count the number of documents the term occurs in 
	 *  @param term (the term to count occurrences of)
	 *  @return the number of documents the term occurs in */
	public static int countOccurances(Term term) {
		int a = 0;
		for (LinearProbingHashST<String, Term> file : fileList) {
			if (file.contains(term.word)) a++;
		} return a;
	}
	
	/** print to the console the documents that contain a certain word,
	 * the frequency of the word in each document, and the tf-idf score
	 * @param key (word to search for, as a String) */
	public static void search(String key) {
		boolean found = false;
		System.out.println("SEARCH KEY: " + key);
		for (LinearProbingHashST<String, Term> file : fileList) {
			if (file.contains(key)) {
				found = true;
				System.out.println("  DOCUMENT: " + file.get(key).document.substring(9) +
						"\n    FREQUENCY: " + file.get(key).frequency +
						"\n    TF-IDF: " + file.get(key).tf_idf);
			}
		}
		
		if (!found) System.out.println("  NOT PRESENT IN ANY DOCUMENTS");
		System.out.println();
	}
	
	/** print to the console the top ten terms for a document, by tf-idf score
	 * @param doc (document to search through, as a LinearProbingHashST<String, Term>) */
	public static void top10(LinearProbingHashST<String, Term> doc) {
		Term[] terms = new Term[doc.N];
		int idx = 0;
		
		for (Term term : doc) {
			if (term != null) {
				terms[idx] = term;
				idx++;
			}
		}
		
		QuickSort.sort(terms);
		int j = 1;
		for (int i = doc.N - 1; i >= doc.N - 10; i--) {
			System.out.println("  " + j + ". " + terms[i].word);
			j++;
		}
		System.out.println();
	}
	
	/** read in plain text files and create a hash table that stores a key and a term
	 * @param fileName (path of file to be read in, as a String)
	 * @return hash table that contains the key and term for the file */
	public static LinearProbingHashST<String, Term> readIn(String fileName) {
		LinearProbingHashST<String, Term> table = new LinearProbingHashST<String, Term>();
		LinkedList<String> arr = new LinkedList<String>();
		Scanner scanner;
		
		try {
			scanner = new Scanner(new File(fileName));
			while (scanner.hasNext())
	            arr.add(Arrays.toString(scanner.next().replaceAll("'", "").replaceAll("-", "").split("[\\s\\p{Punct}]+")));
			
			for (String a : arr) {
				if (!table.contains(a)) table.put(a, new Term(a, fileName, 1));
				else table.put(a, new Term(a, fileName, table.get(a).frequency + 1));
			} scanner.close();
			
		} catch (FileNotFoundException e) { e.printStackTrace(); }
		return table;
	}
	
	/** create a sample of search items by randomly choosing N keys, where N is
	 * 1/10 of all of the possible words in all documents
	 * @return a linked list of random words */
	public static LinkedList<String> searchEvalList() {
		LinkedList<String> allWords = new LinkedList<String>();
		LinkedList<String> randWords = new LinkedList<String>();
		
		for (Term term : docFreq)
			if (term != null) allWords.add(term.word);
		
		for (int i = 0; i < (allWords.size() / 10); i++)
			randWords.add(allWords.get((int)(Math.random() * allWords.size())));
		
		return randWords;
	}
	
	/** conduct an empirical evaluation of the search method, using random keys
	 * and testing search performance on a test set ten times with a stop watch
	 * @param randWords (random keys to search for, as a LinkedList)
	 * @return the time, in ms, that each test set took to search */
	public static LinkedList<Double> searchEval(LinkedList<String> randWords) {
		LinkedList<Double> times = new LinkedList<Double>();
		Stopwatch watch = new Stopwatch();
		
		for (int i = 1; i <= 10; i++) {
			watch.start();
			for (String word : randWords) search(word);
			watch.stop();
			times.add(watch.getElapsedMS());
			watch.reset();
		}
		return times;
	}
	
	/** conduct an empirical evaluation of the construction of the hash table 
	 * for one file and print the time, in ms, to the console */
	public static void constructionEval() {
		Stopwatch watch = new Stopwatch();
		watch.start();
		readIn("src/data/bustopher-jones-the-cat-about-town.txt");
		watch.stop();
		System.out.println("CONSTRUCTION EMPERICAL EVALUATION:\n  " + watch.getElapsedMS() + " ms\n");
		watch.reset();
	}
}
