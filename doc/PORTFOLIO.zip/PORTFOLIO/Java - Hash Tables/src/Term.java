
public class Term implements Comparable<Term> {
	String word, document;
	int frequency;
	double tf, idf, tf_idf;
	
	public Term(String word, String document, int frequency) {
		this.word = word;
		this.document = document;
		this.frequency = frequency;
		this.tf = 0;
		this.idf = 0;
		this.tf_idf = 0;
	}

	public int compareTo(Term a) {
		if (this.tf_idf > a.tf_idf) return 1;
		else if (this.tf_idf < a.tf_idf) return -1;
		else return 0;
	}
}
